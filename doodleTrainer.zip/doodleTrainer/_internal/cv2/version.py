opencv_version = "4.8.1.78"
contrib = False
headless = False
rolling = False
ci_build = True